from getpass import getpass
username = input("Type your Username - ")
